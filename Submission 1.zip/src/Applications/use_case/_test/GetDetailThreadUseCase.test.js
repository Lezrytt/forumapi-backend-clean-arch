const GetDetailThreadUseCase = require('../GetDetailThreadUseCase');
const ThreadRepository = require('../../../Domains/threads/ThreadRepository');

describe('GetDetailThreadUseCase', () => {
  it('should simulate get thread detail correctly', async () => {
    const expectedThread = {
      id: 'thread-123',
      title: 'sebuah thread',
      body: 'sebuah body thread',
      date: new Date().toISOString(),
      username: 'dicoding',
      comments: [{
        id: 'comment-id_test1',
        content: 'comment content test',
        date: '2022-04-04 04:04:05.012345',
        username: 'johndoe',
      },
      {
        id: 'comment-id_test2',
        content: 'comment content test2',
        date: '2022-04-04 04:04:05.012345',
        username: 'johndoe',
      },
      ],
    };

    const mockThreadRepository = new ThreadRepository();

    mockThreadRepository.getDetailThread = jest.fn()
      .mockImplementation(() => Promise.resolve(expectedThread));

    const getDetailThreadUseCase = new GetDetailThreadUseCase({
      threadRepository: mockThreadRepository,
    });

    const thread = await getDetailThreadUseCase.execute('thread-123');

    // action
    expect(thread).toStrictEqual(expectedThread);
    expect(mockThreadRepository.getDetailThread).toBeCalledWith('thread-123');
  });
});
