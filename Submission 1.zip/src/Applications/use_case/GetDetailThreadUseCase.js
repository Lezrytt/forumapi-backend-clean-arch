class GetDetailThreadUseCase {
  constructor({ threadRepository }) {
    this._threadRepository = threadRepository;
  }

  async execute(threadId) {
    return this._threadRepository.getDetailThread(threadId);
  }
}

module.exports = GetDetailThreadUseCase;
