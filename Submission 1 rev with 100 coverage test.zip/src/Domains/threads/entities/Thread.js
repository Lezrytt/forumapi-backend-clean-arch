Class Thread {
  constructor(threadId) {
  this._verifyParams{threadId}

  this.threadId =
}